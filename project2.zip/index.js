window.onload = function() 
{
    GetAllCoins();
}
var listOfData=[];
var listOfMoreInfoData=[];
var listOfMoreInfoDataCounter=0;
var listOfRadioSelector=[];
var moreInfo=[];
var listOfRadioSelectorCounter=0;
document.querySelector("#home").addEventListener('click' , setRoute );
document.querySelector("#LiveReports").addEventListener('click' , setRoute );
document.querySelector("#about").addEventListener('click' , setRoute );

const Actions = {            
  Home,            
  LiveReports,            
  About            
}
function checkIfClicked(id)
{
    for(let s=0;s<listOfRadioSelectorCounter;s++)
    {
        if(listOfRadioSelector[s]==id)
        {
            return 1;
        }
    }
    return -1;
}
function getFromArrayList(id)
{
    for(var c=0;c<100;c++)
    {
        if(listOfData[c].id==id)
        {
            return listOfData[c];
        }
    }
}
function getMoreInfoFunction(id)
{  
    var found=-1;
        for(var e=0 ; e< listOfMoreInfoData.length;e++)
        {
            if(listOfMoreInfoData[e]==id)
            {
                found=e;
                break;
            }
        } 
        var html =" ";
        if(found!=-1)
        {
            listOfMoreInfoData.splice(found, 1); 
            listOfMoreInfoDataCounter--;
            document.querySelector(`#moreInfo${id}`).innerHTML = html;
        }
    if(!idExists(id,found))
    {
        if(found==-1)
        {
            listOfMoreInfoData[listOfMoreInfoDataCounter]=id;
            listOfMoreInfoDataCounter++;
            var requestOptions = {
                method: 'GET'
            };
            fetch(`https://api.coingecko.com/api/v3/coins/${id}`, requestOptions)
                .then(response => response.json())
                .then(data => 
                    {
                    html+=`<img src="${data.image.small}"><br>`;
                    html+='USD:';
                    html+=data.market_data.current_price.usd;
                    html+='$<br>';
                    html+='ILS:';
                    html+=data.market_data.current_price.ils;
                    html+='₪<br>';
                    html+='EUR:';
                    html+=data.market_data.current_price.eur;
                    html+='€<br>';

                    let temp={id:id,time:new Date().getTime(), img:data.image.small,
                        usd:data.market_data.current_price.usd,eur:data.market_data.current_price.eur
                         ,ils:data.market_data.current_price.ils};
                     moreInfo.push(temp);         
                    document.querySelector(`#moreInfo${id}`).innerHTML = html;
                    localStorage.setItem(`#moreInfo${id}`, JSON.stringify(temp));
                    console.log(temp);
                }
                    )
                .catch(error => console.log('error', error));
        }
    }
}
function idExists(idd,found) {
    
    if(found==-1)
    {
        var fo=-1;
        for(var e=0 ; e< listOfMoreInfoData.length;e++)
        {
            if(listOfMoreInfoData[e]==idd)
            {
                fo=e;
            }
        } 
        if(fo==-1)
        {
            listOfMoreInfoData[listOfMoreInfoDataCounter]=idd;
            listOfMoreInfoDataCounter++;    
        }
        return moreInfo.some(function(el) {
            if( el.id === idd){
                let twoMin = 1000 * 60 * 2; 
                let isPast= (new Date().getTime() - el.time < twoMin)?false:true;
                if(isPast)
                {
                    return false
                }else
                {
                    let tmp = JSON.parse(localStorage.getItem(`#moreInfo${idd}`));
                    if(tmp===null)
                        return false;
                 let html=`<p>
                    <img src="${tmp.img}" class="imgg"> <br>
                    USD: ${tmp.usd}$<br>
                    EUR: ${tmp.eur}€<br>
                    ILS:${tmp.ils}₪
                </p>`
                 document.querySelector(`#moreInfo${idd}`).innerHTML = html;
                 return true;
                }
            }
            return false;
        }); 
    }
    return true;
}
function setAllCoin()  
{ 
    var  html=" ";
    html+=`<div class="row">`;
    html+=`<dialog id="dialog">
    </dialog>`;
    for (var m=0 ; m<100; m++) 
    {  
        html+=`<div class="col-sm-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">${listOfData[m].symbol}</h5>
                    <label class="switch">`;
                    if(checkIfClicked(listOfData[m].id)==1)
                    {//with checked
                        html+=`<input type="checkbox" checked id=${listOfData[m].id} onClick=lol("${listOfData[m].id}")>
                    `;
                    }
                    else
                    {
                        html+=`<input type="checkbox" id=${listOfData[m].id} onClick=lol("${listOfData[m].id}")>
                    `;
                    }
                    html+=`<span class="slider round" id=${listOfData[m].id}></span>
                    </label>
                    <p class="card-text">${listOfData[m].id}</p>                    
                    <button type="button" class="btn btn-info" data-toggle="collapse" data-target=${listOfData[m].id}   id=${listOfData[m].id}  onClick=getMoreInfoFunction("${listOfData[m].id}")>More Info</button>
                    <div id=${listOfData[m].id}class="collapse">
                    `;
                    html+=`<div id="moreInfo${listOfData[m].id}">
                    </div>`;
                 html+=`</div>
             </div>
            </div>
        </div>`;
    } 
    html+=`</div>`;
    document.querySelector("#main").innerHTML = html;
}
function listOfRadioSelect(id)
{
    window.dialog.close();    
    var ss;
    for(let s=0;s<listOfRadioSelectorCounter;s++)
    {
        if(listOfRadioSelector[s]==id)
        {
            ss=s;
        }
    }
    document.getElementById(id).checked=false;
    listOfRadioSelector.splice(ss, 1); 
    listOfRadioSelectorCounter--;   
    setAllCoin(); 
}
function closeDialog()
{
    window.dialog.close();
}
function showOnMoadul()
{
    var  htm=" ";
    htm+=`<div class="row">`;
    htm+=`<h3> delete some element </h3>`;
    for(let s=0;s<listOfRadioSelectorCounter;s++)
    {
        let v = getFromArrayList(listOfRadioSelector[s]);
        htm+=`<div class="col-sm-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">${v.symbol}</h5>
                <label class="switch">
                    <input type="checkbox" checked id=${v.id} onClick=listOfRadioSelect("${v.id}")>
                    <span class="slider round" id=${v.id}></span>
                </label>
            </div>
        </div>
        </div>`;
    }
    htm+=`<button  class="btn btn-primary" onclick="closeDialog()">close</button>`; 
    htm+=`</div>`;               
    document.getElementById("dialog").innerHTML=htm;
    window.dialog.showModal();
}
function lol(id)
{
    var radioAlreadyClicked=-1;
    var ss;
    for(let s=0;s<listOfRadioSelectorCounter;s++)
    {
        if(listOfRadioSelector[s]==id)
        {
            radioAlreadyClicked=1;
            ss=s;
        }
    }
    if(radioAlreadyClicked==1)
    {
        document.getElementById(id).checked=false;
        listOfRadioSelector.splice(ss, 1);
        listOfRadioSelectorCounter--;        
    }
    else
    {
         if(listOfRadioSelectorCounter<5)
         {
             listOfRadioSelector[listOfRadioSelectorCounter]=id;
             listOfRadioSelectorCounter++;
         }  
         else
         {
            document.getElementById(id).checked=false;
            showOnMoadul();
         }  
    }
}
function setRoute() {
let route = event.target.text;
if(route=='Home')
{
    route='Home';
}
if(route=='Live Reports')
{
    route='LiveReports';
}
const outlet = document.querySelector("#main")
Actions[route](outlet);
event.preventDefault()
}        
function Home(outlet)  
{
    GetAllCoins();
}
function GetAllCoins()
{
    var requestOptions = 
    {
        method: 'GET'
    };
      fetch("https://api.coingecko.com/api/v3/coins/list", requestOptions)
        .then(response => response.json())
        .then(data => {
            listOfData=data;
            setAllCoin();
        }
            )
        .catch(error => console.log('error', error));
}
function LiveReports(outlet) 
{
    outlet.innerHTML = `<div>LiveReports</div>`
}
function About(outlet) 
{
    outlet.innerHTML="<h1 id='aboutMeName'>Mohamed Alyan</h1><br><img id='myPhoto' src='./img/profile.jpg'> <div id='aboutMeParagraph'> <p id='pp'>on this project we show coins by getting it from Api, also we can search about it on search section by enter the symbol</p></div>";
}
function searchMethodFunction()
{
    var f= document.getElementById("searchInput").value;
    var  html=" ";
    html+=`<div class="row">`;
    html+=`<dialog id="dialog">
    </dialog>`;
    for (var m=0 ; m<100; m++) 
    {  
        if(  f.localeCompare(listOfData[m].symbol)==0)
        {
        html+=`<div class="col-sm-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">${listOfData[m].symbol}</h5>
                    <label class="switch">`;
                    if(checkIfClicked(listOfData[m].id)==1)
                    {//with checked
                        html+=`<input type="checkbox" checked id=${listOfData[m].id} onClick=lol("${listOfData[m].id}")>
                    `;
                    }
                    else
                    {
                        html+=`<input type="checkbox" id=${listOfData[m].id} onClick=lol("${listOfData[m].id}")>
                    `;
                    }
                    html+=`<span class="slider round" id=${listOfData[m].id}></span>
                    </label>
                    <p class="card-text">${listOfData[m].id}</p>                    
                    <button type="button" class="btn btn-info" data-toggle="collapse" data-target=${listOfData[m].id}   id=${listOfData[m].id}  onClick=getMoreInfoFunction("${listOfData[m].id}")>More Info</button>
                    <div id=${listOfData[m].id}class="collapse">
                    `;
                    html+=`<div id="moreInfo${listOfData[m].id}">
                    </div>`;
                 html+=`</div>
             </div>
            </div>
        </div>`;
    }  
    } 
    html+=`</div>`;
    document.querySelector("#main").innerHTML = html;
}